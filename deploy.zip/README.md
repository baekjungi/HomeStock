# HomeStock
집에 있는 생필품을 똑똑하게 관리하는 생활용품 재고 관리 서비스를 만드는 프로젝트입니다.

## 실행 방법
1. Node.js 20+ 설치
2. 의존성 설치
	- `npm install`
3. 서버 실행
	- `npm start`
4. 브라우저에서 접속
	- `http://localhost:5501`

참고:
- 기본 화면만 볼 때는 `index.html` 직접 실행도 가능하지만,
- AI 기능은 반드시 `npm start`로 서버를 켜야 동작합니다.

## 현재 구현된 MVP 기능
- 생필품 등록(품목명, 단위, 수량, 최소 보유 기준, 유통기한)
- 바코드 입력 및 카메라 스캔 기반 등록
- 재고 목록 확인 및 품목 삭제
- 사용 기록(+1) / 구매 기록(+1) 버튼으로 수량 자동 갱신
- 사용 기록 기반 예상 소진일 계산
- 소진 임박/재고 부족/유통기한 임박 알림
- 조건 기반 장보기 리스트 자동 생성
- `집에 있어?` 빠른 조회
- 월간 소비 리포트(전월 대비 증감)
- 가족 공유 모드(공유코드 저장소) + 데이터 복사/붙여넣기 동기화
- 샘플 데이터 자동 입력 버튼

## 가족 공유 사용법
1. 가족끼리 같은 공유코드를 정합니다. (예: `family-lee-2026`)
2. 각자 앱에서 공유코드를 입력하고 `공유코드 연결`을 누릅니다.
3. 한 기기에서 `공유 데이터 복사`를 누른 뒤 텍스트를 가족에게 전달합니다.
4. 다른 기기에서 텍스트를 붙여넣고 `붙여넣기 데이터 적용`을 누르면 동기화됩니다.

## 바코드 스캔 사용법
1. `바코드 스캔 > 스캔 시작` 클릭
2. 카메라 권한 허용
3. 바코드를 비추면 품목 정보가 폼에 자동 입력

참고:
- 기본은 `BarcodeDetector`로 스캔하고, 인식이 지연되면 자동으로 `ZXing` 호환 모드로 전환됩니다.
- 인터넷 연결이 없으면 ZXing CDN을 불러오지 못할 수 있습니다.

## Firebase 실시간 동기화 (무료한도 기준)
기본은 로컬 모드이며, Firebase를 설정하면 가족코드 기준 실시간 동기화가 켜집니다.

설정 방법:
1. Firebase 콘솔에서 프로젝트 생성 (Spark 무료 요금제)
2. Authentication > 로그인 방법 > `익명` 활성화
3. Firestore Database 생성 (테스트 후 보안 규칙 적용)
4. `firebase-config.js` 파일의 `window.FIREBASE_CONFIG` 값 채우기
5. 앱 새로고침 후 공유코드 입력

무료한도 절약 포인트:
- 가족코드당 문서 1개(`families/{familyCode}`)만 사용
- 쓰기 디바운스(약 1.2초) 적용으로 쓰기 횟수 감소
- 실시간 리스너 1개만 유지

권장 보안 규칙 예시(개발용):
```txt
rules_version = '2';
service cloud.firestore {
	match /databases/{database}/documents {
		match /families/{familyCode} {
			allow read, write: if request.auth != null;
		}
	}
}
```

## 데이터 저장
- 브라우저 `localStorage`에 저장됩니다.
- 브라우저 데이터를 지우면 기록이 초기화됩니다.

## Azure AI 연동 설정
HomeStock AI 도우미는 API 키를 브라우저에 노출하지 않기 위해 서버 프록시(`/api/ai-chat`)로 동작합니다.

1. `.env.example` 파일을 참고해 `.env` 파일 생성
2. 아래 값 채우기
	- `AZURE_OPENAI_ENDPOINT`
	- `AZURE_OPENAI_DEPLOYMENT`
	- `AZURE_OPENAI_API_KEY`
	- `AZURE_OPENAI_API_VERSION` (기본값: `2024-10-21`)
3. `npm start`로 서버 재시작

보안 주의:
- `firebase-config.js` 같은 클라이언트 파일에 Azure API 키를 직접 넣지 마세요.
- 키는 서버 환경변수로만 관리하세요.
